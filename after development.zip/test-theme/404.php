<?php get_header(); ?>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

       
        <!-- /.col-lg-3 -->

        <div class="col-lg-12">

          

          <div class="row">
			
				
			<h1>404 not found.</h1>
			
			
            

            

          
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php get_footer(); ?>
