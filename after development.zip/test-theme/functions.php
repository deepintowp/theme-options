<?php 
/*
* GLOBALS
*/
define('THEME_PATH', get_template_directory());
define('THEME_URI', get_template_directory_uri());


/*
*	THEME SUPPORT AND SETUP
*/
//get_option
//hide adminbar from front end
show_admin_bar(false );


/*
*	INCLUDES
*/
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/theme_optiopns/ReduxCore/framework.php' ) ) {
    require_once( dirname( __FILE__ ) . '/theme_optiopns/ReduxCore/framework.php' );
}
if ( !isset( $redux_demo ) && file_exists( dirname( __FILE__ ) . '/theme_optiopns/test_theme/config.php' ) ) {
    require_once( dirname( __FILE__ ) . '/theme_optiopns/test_theme/config.php' );
}





//front
include(THEME_PATH.'/include/front/enqueue.php');
include(THEME_PATH.'/include/front/menus.php');
include(THEME_PATH.'/include/front/walker.php');
include(THEME_PATH.'/include/front/widget.php');


function add_classes_wpse_130358($classes, $item, $args) {
  $classes[] = 'nav-item';
  
  
  return $classes;
}
add_filter('nav_menu_css_class','add_classes_wpse_130358',1,3);
function add_classes_wpse_1303581($atts, $item, $args ) {
  
  $atts['class'] = 'nav-link';
  return $atts;
}
add_filter('nav_menu_link_attributes','add_classes_wpse_1303581',1,3);

/*
*	HOOKS
*/
add_action('wp_enqueue_scripts', 'Subho_front_enqueue');
add_action( 'after_setup_theme', 'Subho_register_menus' );
add_action( 'widgets_init', 'test_theme_widgets_init' );


