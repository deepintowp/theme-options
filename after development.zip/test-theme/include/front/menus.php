<?php 


function Subho_register_menus() {
  register_nav_menu( 'primary', __( 'Primary Menu', 'theme-slug' ) );
   add_image_size( 'post_grid_thumb', 700, 400, true );
   add_theme_support( 'post-thumbnails' );
add_theme_support( 'menus' );
add_theme_support( 'post-formats', array( 'aside', 'gallery', 'audio' ) );
add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
register_nav_menus( array(
	'main_menu' => 'Main Menu'
) );
  add_theme_support( 'woocommerce' );
}