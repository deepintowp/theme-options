<?php get_header(); ?>
<?php global $test_theme; ?>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

          <!-- <h1 class="my-4">Shop Name</h1> -->
          <!-- <div class="list-group"> -->
            <!-- <a href="#" class="list-group-item">Category 1</a> -->
            <!-- <a href="#" class="list-group-item">Category 2</a> -->
            <!-- <a href="#" class="list-group-item">Category 3</a> -->
          <!-- </div> -->
			<?php get_sidebar(); ?>
			<?php get_search_form(); ?>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

          <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
			
				<?php 
				
					
					if(count($test_theme['themesliser'])){
						$i = 0;
						foreach($test_theme['themesliser'] as $slider){
							?>
							<div class="carousel-item <?php if($i == 0 ){ echo 'active'; } ?>">
								<img  class="d-block img-fluid" src="<?php echo $slider['image']; ?>" alt="First slide">
							  </div>
							<?php 
							$i++;
						}
						
					}
					
				
				?>
			
			
			
			
              
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>

          <div class="row">
			<?php 
				if(have_posts()){
					while(have_posts()){
						the_post();
					?>
					<div class="col-lg-4 col-md-6 mb-4">
					  <div class="card h-100">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('post_grid_thumb', array('class'=>'card-img-top'));  ?></a>
						<div class="card-body">
						  <h4 class="card-title">
							<a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
						  </h4>
						  
						  <p class="card-text"><?php echo get_the_excerpt(); ?></p>
						</div>
						<div class="card-footer">
						  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
						</div>
					  </div>
					</div>
					
					
					
					<?php
					}
					 wp_reset_postdata();
				}
			 previous_posts_link('prev'); 
			 next_posts_link('next'); 
			
			?>
            

            

          
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php get_footer(); ?>
