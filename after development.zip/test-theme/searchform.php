<form id="searchform" class="test_theme_search_form" method="get" action="<?php echo home_url('/'); ?>">
  <div>
	 <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" size="15" /><br />
	 <input type="submit" value="Search" />
  </div>
</form>