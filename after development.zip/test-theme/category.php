<?php get_header(); ?>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

          <!-- <h1 class="my-4">Shop Name</h1> -->
          <!-- <div class="list-group"> -->
            <!-- <a href="#" class="list-group-item">Category 1</a> -->
            <!-- <a href="#" class="list-group-item">Category 2</a> -->
            <!-- <a href="#" class="list-group-item">Category 3</a> -->
          <!-- </div> -->
			<?php get_sidebar(); ?>
			<?php get_search_form(); ?>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

          <?php the_archive_title('<h1 class="page-title">', '</h1>'); ?>

          <div class="row">
			<?php 
				if(have_posts()){
					while(have_posts()){
						the_post();
					?>
					<div class="col-lg-4 col-md-6 mb-4">
					  <div class="card h-100">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('post_grid_thumb', array('class'=>'card-img-top'));  ?></a>
						<div class="card-body">
						  <h4 class="card-title">
							<a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
						  </h4>
						  
						  <p class="card-text"><?php echo get_the_excerpt(); ?></p>
						</div>
						<div class="card-footer">
						  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
						</div>
					  </div>
					</div>
					
					
					
					<?php
					}
					 wp_reset_postdata();
				}
			 previous_posts_link('prev'); 
			 next_posts_link('next'); 
			
			?>
            

            

          
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php get_footer(); ?>
