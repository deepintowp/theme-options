jQuery(document).ready(function($){

   
        $('.newstape').newstape();
   

	
});