<?php 


function Subho_front_enqueue(){
	wp_register_style( 'bootstrap', THEME_URI.'/vendor/bootstrap/css/bootstrap.min.css', array(), '3.0', 'all' );
	wp_register_style( 'shop-homepage', THEME_URI.'/css/shop-homepage.css', array(), '1.0', 'all' );
	wp_register_style( 'theme_style', THEME_URI.'/style.css', array(), '1.0', 'all' );
	
	wp_enqueue_style('bootstrap');
	wp_enqueue_style('shop-homepage');
	wp_enqueue_style('theme_style');
	
	
	wp_register_script( 'popper_js', THEME_URI.'/vendor/popper/popper.min.js', array('jquery'), '1.0', true );
	wp_register_script( 'bootstrap_js', THEME_URI.'/vendor/bootstrap/js/bootstrap.min.js', array('jquery'), '1.0', true );
	wp_register_script( 'mousewheel', THEME_URI.'/js/jquery.mousewheel.min.js', array('jquery'), '1.0', true );
	wp_register_script( 'drag.min', THEME_URI.'/js/jquery.event.drag.min.js', array('jquery'), '1.0', true );
	wp_register_script( 'newstape', THEME_URI.'/js/jquery.newstape.js', array('jquery'), '1.0', true );
	wp_register_script( 'custom', THEME_URI.'/js/custom.js', array('jquery'), '1.0', true );
	
	wp_enqueue_script('popper_js');
	wp_enqueue_script('bootstrap_js');
	wp_enqueue_script('mousewheel');
	wp_enqueue_script('drag.min');
	wp_enqueue_script('newstape');
	wp_enqueue_script('custom');
}