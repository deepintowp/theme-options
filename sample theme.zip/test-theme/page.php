<?php get_header(); ?>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">

         
			<?php get_sidebar(); ?>
			<?php get_search_form(); ?>
        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

          

          <div class="row">
			<?php 
				if(have_posts()){
					while(have_posts()){
						the_post();
					?>
					<div class="col-lg-12 col-md-12 mb-12">
					  <div class="card h-100">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('large', array('class'=>'card-img-top'));  ?></a>
						<div class="card-body">
						  <h4 class="card-title">
							<a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
						  </h4>
						  
						  <p class="card-text"><?php echo get_the_content(); ?></p>
						</div>
						<div class="card-footer">
						  <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
						</div>
					  </div>
					</div>
					
					
					
					<?php
					}
					 wp_reset_postdata();
				}
			
			
			?>
            

            

          
            </div>

          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->
<?php get_footer(); ?>
