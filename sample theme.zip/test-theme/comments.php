<?php
if(comments_open()){
	?> 
	<form action="<?php echo site_url('wp-comments-post.php'); ?>" class="col-md-12" method="post">
		<input id="comments_post_ID" name="comment_post_ID" value="<?php echo $post->ID;  ?>" type="hidden" />
		<div class="form-group">
			<label for="name">Name:</label>
			<input id="name" name="author" type="text" class="form-control">
		</div>
		<div class="form-group">
			<label for="email">Email:</label>
			<input name="email" type="email" class="form-control" id="email">
		</div>
		<div class="form-group">
			<label for="website">Website:</label>
			<input name="url" type="text" class="form-control" id="website">
		</div>
		<div class="form-group">
			<label for="comment">Comment:</label>
			<textarea name="comment" id="" cols="60" rows="7"></textarea>
		</div>
		<div class="form-group">
			<input name="submit" type="submit" class="form-control" id="submit">
		</div>
		
	</form>
	<?php
	
}else{
	_e('Comments apre closed.', 'theme-slag');
	
}